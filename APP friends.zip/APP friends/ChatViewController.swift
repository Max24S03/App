import UIKit
import Firebase

class ChatViewController: UIViewController {
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var messageTextField: UITextField!
    
    var messages: [Message] = []
    var chatPartner: User?

    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource = self
        fetchMessages()
    }

    func fetchMessages() {
        guard let chatPartnerID = chatPartner?.userID else { return }
        let db = Firestore.firestore()
        db.collection("messages").whereField("receiverID", isEqualTo: chatPartnerID).addSnapshotListener { snapshot, error in
            if let error = error {
                print("Error fetching messages: \(error.localizedDescription)")
            } else {
                self.messages = snapshot?.documents.compactMap { document -> Message? in
                    let data = document.data()
                    guard let senderID = data["senderID"] as? String,
                          let receiverID = data["receiverID"] as? String,
                          let text = data["text"] as? String,
                          let timestamp = data["timestamp"] as? Timestamp else { return nil }
                    return Message(senderID: senderID, receiverID: receiverID, text: text, timestamp: timestamp.dateValue())
                } ?? []
                self.tableView.reloadData()
            }
        }
    }

    @IBAction func sendMessage(_ sender: UIButton) {
        guard let messageText = messageTextField.text, !messageText.isEmpty, let senderID = Auth.auth().currentUser?.uid else { return }
        guard let receiverID = chatPartner?.userID else { return }
        let db = Firestore.firestore()
        let messageData: [String: Any] = [
            "senderID": senderID,
            "receiverID": receiverID,
            "text": messageText,
            "timestamp": Timestamp(date: Date())
        ]
        db.collection("messages").addDocument(data: messageData) { error in
            if let error = error {
                print("Error sending message: \(error.localizedDescription)")
            } else {
                self.messageTextField.text = ""
            }
        }
    }
}

extension ChatViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return messages.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MessageCell", for: indexPath)
        let message = messages[indexPath.row]
        cell.textLabel?.text = message.text
        return cell
    }
}

struct Message {
    var senderID: String
    var receiverID: String
    var text: String
    var timestamp: Date
}