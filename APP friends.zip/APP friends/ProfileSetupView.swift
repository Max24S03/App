import SwiftUI
import Firebase

struct ProfileSetupView: View {
    @State private var name: String = ""
    @State private var gender: Int = 0
    @State private var location: String = ""

    var body: some View {
        VStack {
            TextField("Name", text: $name)
                .padding()
                .background(Color(.systemGray6))
                .cornerRadius(10)
            
            Picker("Gender", selection: $gender) {
                Text("Male").tag(0)
                Text("Female").tag(1)
            }
            .pickerStyle(SegmentedPickerStyle())
            .padding()
            
            TextField("Location", text: $location)
                .padding()
                .background(Color(.systemGray6))
                .cornerRadius(10)
            
            Button(action: saveProfile) {
                Text("Save Profile")
                    .foregroundColor(.white)
                    .padding()
                    .background(Color.blue)
                    .cornerRadius(10)
            }
        }
        .padding()
    }
    
    func saveProfile() {
        guard let userID = Auth.auth().currentUser?.uid else { return }
        let genderString = gender == 0 ? "Male" : "Female"
        
        let db = Firestore.firestore()
        db.collection("users").document(userID).setData([
            "name": name,
            "gender": genderString,
            "location": location
        ]) { error in
            if let error = error {
                print("Error saving profile: \(error.localizedDescription)")
            } else {
                // Handle navigation to main app screen
            }
        }
    }
}