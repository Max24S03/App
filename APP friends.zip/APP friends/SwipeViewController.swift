import UIKit
import Koloda
import Firebase

class SwipeViewController: UIViewController {
    @IBOutlet weak var kolodaView: KolodaView!
    var users: [User] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        kolodaView.dataSource = self
        kolodaView.delegate = self
        fetchUsers()
    }

    func fetchUsers() {
        let db = Firestore.firestore()
        db.collection("users").getDocuments { snapshot, error in
            if let error = error {
                print("Error fetching users: \(error.localizedDescription)")
            } else {
                self.users = snapshot?.documents.compactMap {
                    let data = $0.data()
                    return User(name: data["name"] as? String ?? "",
                                gender: data["gender"] as? String ?? "",
                                location: data["location"] as? String ?? "",
                                userID: $0.documentID)
                } ?? []
                self.kolodaView.reloadData()
            }
        }
    }
}

extension SwipeViewController: KolodaViewDataSource, KolodaViewDelegate {
    func kolodaNumberOfCards(_ koloda: KolodaView) -> Int {
        return users.count
    }

    func koloda(_ koloda: Koloda